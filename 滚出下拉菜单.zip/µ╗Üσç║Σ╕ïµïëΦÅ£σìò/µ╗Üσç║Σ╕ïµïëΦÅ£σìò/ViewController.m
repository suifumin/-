//
//  ViewController.m
//  滚出下拉菜单
//
//  Created by sfm on 16/6/3.
//  Copyright © 2016年 sfm. All rights reserved.
//

#import "ViewController.h"
#define MainScreen [UIScreen mainScreen].bounds.size
@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *screenButton;
/**
 *  判断按钮是否为选中状态
 */
@property(nonatomic,assign)BOOL IsSelectedButton;
/**
 *  记录弹出的View
 */
@property(nonatomic,strong)UIView *corverView;
/**
 *  用来记录被选中的按钮
 */
@property(nonatomic,strong)UIButton *selectedButton;
/**
 *  用来记录上一次点击的按钮
 */
@property(nonatomic,strong)UIButton *clickButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
}
- (IBAction)ClickButton:(UIButton *)sender {
    if (self.clickButton != sender) {
        [self setUpNotTimeLimitViewUp];
        [self.corverView removeFromSuperview];
    }
    
    
    if (sender.selected == NO) {
        sender.selected = YES;
        
        
        [self setUpNotTimeLimitViewDown];
        [self changeClickButton:sender];
    }else if(sender.isSelected == YES){
        sender.selected = NO;
        
        [self setUpNotTimeLimitViewUp];
        
    }
    
    self.clickButton = sender;

}
-(void)changeClickButton:(UIButton *)sender{
    
    self.selectedButton.selected = NO;
    self.selectedButton = sender;
    sender.selected = YES;
    
    
    
}


#pragma mark - 创建不限时按钮的下拉View
- (void)setUpNotTimeLimitViewDown{
    UIView * TouMingView = [[UIView alloc]init];
    self.corverView = TouMingView;
    self.corverView.backgroundColor = [UIColor redColor];
    
    TouMingView.alpha = 0.5;
    TouMingView.frame = CGRectMake(0, 40 + 20 ,MainScreen.width , 0);
    [self.view addSubview:TouMingView];
    [UIView animateWithDuration:0.25 animations:^{
        TouMingView.frame = CGRectMake(0, 40 + 20, MainScreen.width, MainScreen.height  - self.screenButton.bounds.size.height);
    }];
    
    
    
    
}
#pragma MARK -点击不限时按钮弹出的上拉View
- (void)setUpNotTimeLimitViewUp{
    [UIView animateWithDuration:0.25 animations:^{
        CGRect frame =  self.corverView.frame;
        frame.size.height = 0;
        self.corverView.frame = frame;
        
    }];

}
@end
